CREATE TABLE Course
(
   CourseID int,
   CourseName varchar(1000),
   Rating numeric(2,1)
)