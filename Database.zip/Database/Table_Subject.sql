CREATE TABLE Subject
(
   SubjectID int,
   SubjectName varchar(1000),
   Rating numeric(2,1)
)
