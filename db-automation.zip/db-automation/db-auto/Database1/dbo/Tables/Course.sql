﻿CREATE TABLE [dbo].[Course] (
    [CourseID]   INT            NULL,
    [CourseName] VARCHAR (1000) NULL,
    [Rating]     NUMERIC (2, 1) NULL
);

